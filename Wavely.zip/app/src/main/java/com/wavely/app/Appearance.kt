package com.wavely.app

import android.app.Activity

object Appearance {
    val accentIds = listOf("teal", "indigo", "purple", "pink", "orange", "green", "blue")

    fun apply(a: Activity) {
        a.setTheme(
            when (Prefs.accent(a)) {
                "indigo" -> R.style.Theme_Wavely_Indigo
                "purple" -> R.style.Theme_Wavely_Purple
                "pink" -> R.style.Theme_Wavely_Pink
                "orange" -> R.style.Theme_Wavely_Orange
                "green" -> R.style.Theme_Wavely_Green
                "blue" -> R.style.Theme_Wavely_Blue
                else -> R.style.Theme_Wavely_Teal
            }
        )
    }
}
