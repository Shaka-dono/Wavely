package com.wavely.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min

/**
 * Sabbia su una piastra quadrata: la piastra vibra in modi del tipo cos(nπx)cos(mπy) − cos(mπx)cos(nπy).
 * I grani vengono scossi in proporzione a quanto vibra il punto in cui si trovano, quindi col tempo
 * si fermano sulle linee dove la piastra non si muove (linee nodali): le figure di Chladni.
 */
class Chladni(val count: Int = 7000) {
    private class Mode(val n: Int, val m: Int, val k: Int)

    private val modes: List<Mode>
    private val cosT = Array(13) { n -> FloatArray(TAB) { i -> cos(n * PI * i / (TAB - 1)).toFloat() } }
    private val rnd = Rand(12345)
    val x = FloatArray(count)
    val y = FloatArray(count)

    // modi attivi nel fotogramma corrente
    private var an = IntArray(0)
    private var am = IntArray(0)
    private var aw = FloatArray(0)
    @Volatile var strongest = ""

    init {
        val l = ArrayList<Mode>()
        for (n in 0..11) for (m in n + 1..12) l.add(Mode(n, m, n * n + m * m))
        modes = l
        scatter()
    }

    fun scatter() {
        for (i in 0 until count) {
            x[i] = ((rnd.w() + 1.0) * 0.5).toFloat()
            y[i] = ((rnd.w() + 1.0) * 0.5).toFloat()
        }
    }

    /** Sceglie i modi vicini alla frequenza (scala logaritmica 20 Hz – 20 kHz → autovalore 1..~110). */
    fun setFrequency(f: Double) {
        val pos = (ln(f.coerceIn(20.0, 20000.0) / 20.0) / ln(1000.0))
        val kEff = 2.0 + 110.0 * pos
        var best = 0.0
        var bestMode: Mode? = null
        val w = DoubleArray(modes.size)
        for ((i, md) in modes.withIndex()) {
            val d = (kEff - md.k) / 2.2
            w[i] = exp(-d * d)
            if (w[i] > best) { best = w[i]; bestMode = md }
        }
        val ids = ArrayList<Int>()
        for (i in modes.indices) if (w[i] / best > 0.08) ids.add(i)
        an = IntArray(ids.size) { modes[ids[it]].n }
        am = IntArray(ids.size) { modes[ids[it]].m }
        aw = FloatArray(ids.size) { (w[ids[it]] / best).toFloat() }
        strongest = bestMode?.let { "${it.n}, ${it.m}" } ?: ""
    }

    /** ampiezza di vibrazione (0..1) nel punto */
    fun amp(px: Float, py: Float): Float {
        val ix = (px * (TAB - 1)).toInt().coerceIn(0, TAB - 1)
        val iy = (py * (TAB - 1)).toInt().coerceIn(0, TAB - 1)
        var u = 0f
        for (j in an.indices) {
            val cn = cosT[an[j]]
            val cm = cosT[am[j]]
            u += aw[j] * (cn[ix] * cm[iy] - cm[ix] * cn[iy])
        }
        return min(1f, abs(u) * 0.7f)
    }

    /** un passo di simulazione; vib 0..1 = quanto forte è la vibrazione */
    fun step(vib: Float) {
        if (vib <= 0.001f || an.isEmpty()) return
        for (i in 0 until count) {
            val a = amp(x[i], y[i])
            val s = vib * (0.0015f + 0.03f * a)
            var nx = x[i] + rnd.w().toFloat() * s
            var ny = y[i] + rnd.w().toFloat() * s
            if (nx < 0f) nx = -nx else if (nx > 1f) nx = 2f - nx
            if (ny < 0f) ny = -ny else if (ny > 1f) ny = 2f - ny
            x[i] = nx.coerceIn(0f, 1f)
            y[i] = ny.coerceIn(0f, 1f)
        }
    }

    fun meanAmp(): Float {
        var s = 0f
        for (i in 0 until count) s += amp(x[i], y[i])
        return s / count
    }

    companion object {
        const val TAB = 1024
    }
}
