package com.wavely.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min
import kotlin.math.sin

/** Piastra di metallo con la sabbia: disegna la simulazione. */
class ChladniView(context: Context, val sim: Chladni) : View(context) {
    private val d = resources.displayMetrics.density
    private val plate = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.argb(120, 255, 255, 255)
    }
    private val sand = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F1E3B8"); strokeWidth = 2.2f * d; strokeCap = Paint.Cap.ROUND
    }
    private val pts = FloatArray(sim.count * 2)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val side = min(width, height).toFloat()
        val l = (width - side) / 2f
        val t = (height - side) / 2f
        rect.set(l + 4 * d, t + 4 * d, l + side - 4 * d, t + side - 4 * d)
        plate.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.parseColor("#4A5568"), Color.parseColor("#2B323F"), Color.parseColor("#465060")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, 14 * d, 14 * d, plate)
        c.drawRoundRect(rect, 14 * d, 14 * d, edge)
        val inset = 10 * d
        val pw = rect.width() - 2 * inset
        val ph = rect.height() - 2 * inset
        for (i in 0 until sim.count) {
            pts[2 * i] = rect.left + inset + sim.x[i] * pw
            pts[2 * i + 1] = rect.top + inset + sim.y[i] * ph
        }
        c.drawPoints(pts, sand)
    }
}

/** Pagina "Chladni": figure di sabbia che seguono la frequenza del generatore o del microfono. */
class ChladniPage(private val act: MainActivity) : ScrollView(act) {

    private val ctx = act
    private val sim = Chladni()
    private val view = ChladniView(ctx, sim)
    private val analyzer = Spectrum()
    private val tvFreq: TextView
    private val tvMode: TextView
    private val tvHint: TextView
    private val btnPlay: TextView
    private val freqCard: LinearLayout
    private val freqRow: ParamRow
    private val srcSeg: Segmented
    var useMic = false
        private set

    private fun dp(v: Int) = Ui.dp(ctx, v)

    init {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(4), dp(16), dp(24))
        addView(root)

        srcSeg = Segmented(ctx, listOf(ctx.getString(R.string.chl_src_gen), ctx.getString(R.string.src_mic)), 0) { i ->
            if (i == 1) act.requestMic { ok ->
                useMic = ok
                if (!ok) srcSeg.select(0)
                afterSourceChange()
            } else {
                useMic = false
                afterSourceChange()
            }
        }
        val sl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sl.bottomMargin = dp(12)
        root.addView(srcSeg, sl)

        val card = W.card(ctx)
        val box = LinearLayout(ctx)
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        box.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0))
        // altezza = larghezza (piastra quadrata)
        val square = object : LinearLayout(ctx) {
            override fun onMeasure(w: Int, h: Int) {
                val width = MeasureSpec.getSize(w)
                super.onMeasure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY))
            }
        }
        square.orientation = VERTICAL
        card.removeAllViews()
        square.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(square, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(card)

        val info = LinearLayout(ctx)
        info.gravity = Gravity.CENTER_VERTICAL
        info.setPadding(dp(4), dp(14), dp(4), dp(4))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        tvFreq = Ui.label(ctx, "—", 26f, Ui.text(ctx), true)
        tvMode = Ui.label(ctx, "", 14f, Ui.primary(ctx), true)
        col.addView(tvFreq)
        col.addView(tvMode)
        info.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val scatter = Ui.label(ctx, ctx.getString(R.string.chl_scatter), 14f, Ui.text(ctx), true)
        scatter.setPadding(dp(14), dp(12), dp(14), dp(12))
        scatter.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 16)
        scatter.setOnClickListener { Ui.tap(it); sim.scatter() }
        info.addView(scatter)
        btnPlay = TextView(ctx)
        btnPlay.textSize = 20f
        btnPlay.gravity = Gravity.CENTER
        btnPlay.setTextColor(Ui.onPrimary(ctx))
        btnPlay.background = Ui.ovalBg(Ui.primary(ctx))
        val plp = LinearLayout.LayoutParams(dp(52), dp(52))
        plp.marginStart = dp(10)
        btnPlay.setOnClickListener { Ui.tap(it); act.togglePlay() }
        info.addView(btnPlay, plp)
        root.addView(info)

        tvHint = Ui.label(ctx, "", 13f, Ui.secondary(ctx))
        tvHint.setPadding(dp(4), dp(8), dp(4), dp(8))
        root.addView(tvHint)

        freqCard = W.card(ctx)
        freqRow = ParamRow(ctx, ctx.getString(R.string.p_freq), 20.0, 20000.0, true, { Fmt.hz(it) },
            { Engine.patch.freq }, { v -> Engine.update(ctx) { it.copy(freq = v) } })
        freqCard.addView(freqRow)
        root.addView(freqCard)
        afterSourceChange()
    }

    private fun afterSourceChange() {
        freqCard.visibility = if (useMic) View.GONE else View.VISIBLE
        btnPlay.visibility = if (useMic) View.GONE else View.VISIBLE
        tvHint.text = ctx.getString(if (useMic) R.string.chl_hint_mic else R.string.chl_hint_gen)
        analyzer.clear()
        if (useMic) act.micOn() else act.micOff()
    }

    fun onShown() {
        freqRow.sync()
        if (useMic) act.micOn()
    }

    fun onHidden() {
        act.micOff()
    }

    /** ~30 volte al secondo */
    fun frame() {
        var f = 0.0
        var vib = 0f
        if (useMic) {
            analyzer.analyze(Engine.micRing, Prefs.floorDb(ctx))
            if (analyzer.peakDb > -65) {
                f = analyzer.peakFreq
                vib = (((analyzer.peakDb + 65) / 45).toFloat()).coerceIn(0.15f, 1f)
            }
        } else {
            val p = Engine.patch
            btnPlay.text = if (Engine.isPlaying()) "■" else "▶"
            if (Engine.isPlaying()) {
                f = if (p.mode == 3) 400.0 + 350.0 * sin(System.nanoTime() / 1.5e9) + 300.0 * sin(System.nanoTime() / 4.1e8) else Engine.core.currentFreq
                vib = 0.3f + 0.7f * p.volume
            } else {
                f = p.freq
            }
        }
        if (f > 0) {
            sim.setFrequency(f)
            tvFreq.text = Fmt.hz(f)
            tvMode.text = ctx.getString(R.string.chl_mode, sim.strongest) + "  ·  " + Notes.describe(f, Prefs.a4(ctx))
        } else {
            tvFreq.text = "—"
            tvMode.text = ""
        }
        for (i in 0 until 3) sim.step(vib)
        view.invalidate()
    }
}
