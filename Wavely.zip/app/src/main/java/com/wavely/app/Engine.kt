package com.wavely.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.max

/** Collega il generatore all'altoparlante e tiene lo stato condiviso tra schermate e servizio. */
object Engine {
    private const val CHUNK = 1024
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val lock = Object()
    private var thread: Thread? = null
    private var loaded = false

    val core = SynthCore()
    val outRing = Ring()
    val micRing = Ring()

    @Volatile var patch = Patch()
    @Volatile private var wantPlay = false
    @Volatile private var timerEnd = 0L

    fun load(c: Context) {
        if (loaded) return
        loaded = true
        patch = Prefs.loadPatch(c)
    }

    fun update(c: Context?, f: (Patch) -> Patch) {
        val old = patch
        patch = f(old)
        if (wantPlay && patch.timerMin != old.timerMin) {
            val m = patch.timerMin
            timerEnd = if (m <= 0) 0L else SystemClock.elapsedRealtime() + m * 60_000L
        }
        notifyChanged()
    }

    fun savePatch(c: Context) = Prefs.savePatch(c, patch)

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() { main.post { for (l in listeners) l() } }

    fun isPlaying(): Boolean = wantPlay
    fun remainingMs(): Long = if (timerEnd == 0L) -1L else max(0L, timerEnd - SystemClock.elapsedRealtime())

    fun play() {
        val m = patch.timerMin
        timerEnd = if (m > 0) SystemClock.elapsedRealtime() + m * 60_000L else 0L
        core.reset()
        core.running = true
        wantPlay = true
        ensureThread()
        synchronized(lock) { lock.notifyAll() }
        notifyChanged()
    }

    fun stop() {
        wantPlay = false
        core.running = false
        timerEnd = 0L
        notifyChanged()
    }

    private fun ensureThread() {
        if (thread?.isAlive == true) return
        val t = Thread({ audioLoop() }, "wavely-audio")
        t.isDaemon = true
        thread = t
        t.start()
    }

    private fun audioLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val l = FloatArray(CHUNK)
        val r = FloatArray(CHUNK)
        val inter = FloatArray(CHUNK * 2)
        while (true) {
            synchronized(lock) {
                while (!wantPlay) {
                    try {
                        lock.wait()
                    } catch (e: InterruptedException) {
                        return
                    }
                }
            }
            val track = try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(44100)
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(max(CHUNK * 8 * 2, AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build()
            } catch (e: Exception) {
                wantPlay = false
                core.running = false
                notifyChanged()
                continue
            }
            track.play()
            while (true) {
                // timer di spegnimento
                if (wantPlay && timerEnd != 0L && SystemClock.elapsedRealtime() >= timerEnd) {
                    wantPlay = false
                    core.running = false
                    timerEnd = 0L
                    notifyChanged()
                }
                // sweep "una volta" finito
                if (wantPlay && core.finished) {
                    wantPlay = false
                    core.running = false
                    notifyChanged()
                }
                if (!wantPlay && core.isSilent()) break
                core.render(patch, l, r, CHUNK)
                outRing.write(l, CHUNK, r)
                for (i in 0 until CHUNK) {
                    inter[2 * i] = l[i]
                    inter[2 * i + 1] = r[i]
                }
                val w = track.write(inter, 0, inter.size, AudioTrack.WRITE_BLOCKING)
                if (w < 0) break
            }
            try {
                track.stop()
            } catch (e: Exception) {
            }
            track.release()
        }
    }
}

/** Microfono per l'analizzatore (attivo solo mentre la pagina Spettro lo richiede). */
object Mic {
    @Volatile private var running = false
    @Volatile private var token = 0
    private var thread: Thread? = null

    fun isRunning() = running

    fun start(): Boolean {
        if (running) return true
        val min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return false
        val rec = try {
            @Suppress("MissingPermission")
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 44100,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 8192)
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        running = true
        val my = ++token
        val t = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val s = ShortArray(1024)
            val f = FloatArray(1024)
            try {
                rec.startRecording()
                while (running && token == my) {
                    val n = rec.read(s, 0, s.size)
                    if (n <= 0) continue
                    for (i in 0 until n) f[i] = s[i] / 32768f
                    Engine.micRing.write(f, n)
                }
            } catch (e: Exception) {
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                rec.release()
                if (token == my) running = false
            }
        }
        t.isDaemon = true
        thread = t
        t.start()
        return true
    }

    fun stop() {
        running = false
    }
}
