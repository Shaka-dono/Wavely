package com.wavely.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.materialswitch.MaterialSwitch
import kotlin.math.pow

/** Pagina "Genera": tutti i controlli del suono. */
class GeneratorPage(private val act: MainActivity) : ScrollView(act) {

    private val ctx = act
    private val rows = ArrayList<ParamRow>()
    private lateinit var tvFreq: TextView
    private lateinit var tvNote: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnPlay: TextView
    private lateinit var modeSeg: Segmented
    private lateinit var waveSeg: Segmented
    private lateinit var chanSeg: Segmented
    private lateinit var noiseSeg: Segmented
    private lateinit var curveSeg: Segmented
    private lateinit var repeatSeg: Segmented
    private lateinit var tvTimer: TextView
    private lateinit var swAm: MaterialSwitch
    private lateinit var swFm: MaterialSwitch
    private lateinit var cardFreq: LinearLayout
    private lateinit var cardSweep: LinearLayout
    private lateinit var cardBeat: LinearLayout
    private lateinit var cardNoise: LinearLayout
    private lateinit var cardWave: LinearLayout
    private lateinit var amBody: LinearLayout
    private lateinit var fmBody: LinearLayout
    private val titles = HashMap<String, TextView>()

    private fun p() = Engine.patch
    private fun upd(f: (Patch) -> Patch) = Engine.update(ctx, f)
    private fun dp(v: Int) = Ui.dp(ctx, v)
    private fun str(id: Int) = ctx.getString(id)
    private fun arr(id: Int) = ctx.resources.getStringArray(id).toList()

    private fun row(
        title: String, min: Double, max: Double, log: Boolean, show: (Double) -> String,
        get: () -> Double, set: (Double) -> Unit,
        toEdit: (Double) -> Double = { it }, fromEdit: (Double) -> Double = { it }, unit: String = ""
    ): ParamRow {
        val r = ParamRow(ctx, title, min, max, log, show, get, set, toEdit, fromEdit, unit)
        rows.add(r)
        return r
    }

    private fun titled(key: String, text: String, parent: LinearLayout) {
        val t = W.title(ctx, text)
        titles[key] = t
        parent.addView(t)
    }

    init {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(4), dp(16), dp(24))
        addView(root)
        buildHero(root)

        modeSeg = Segmented(
            ctx, listOf(str(R.string.mode_tone), str(R.string.mode_sweep), str(R.string.mode_binaural), str(R.string.mode_noise)),
            p().mode
        ) { m ->
            upd { it.copy(mode = m) }
            refresh()
        }
        val ml = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ml.topMargin = dp(14)
        root.addView(modeSeg, ml)

        // ---- frequenza (tono e binaurale) ----
        titled("freq", str(R.string.sec_frequency), root)
        cardFreq = W.card(ctx)
        cardFreq.addView(row(str(R.string.p_freq), 20.0, 20000.0, true, { Fmt.hz(it) }, { p().freq }, { v -> upd { it.copy(freq = v) } }))
        val fine = LinearLayout(ctx)
        fine.setPadding(dp(12), dp(4), dp(12), dp(10))
        val steps = listOf("−1 st", "−10", "−1", "+1", "+10", "+1 st")
        for (s in steps) {
            val b = Ui.label(ctx, s, 14f, Ui.text(ctx), true)
            b.gravity = Gravity.CENTER
            b.setPadding(0, dp(10), 0, dp(10))
            b.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 12)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(3)
            lp.marginEnd = dp(3)
            b.setOnClickListener {
                Ui.tap(it)
                upd { q ->
                    val f = when (s) {
                        "−1 st" -> q.freq * 2.0.pow(-1.0 / 12.0)
                        "+1 st" -> q.freq * 2.0.pow(1.0 / 12.0)
                        "−10" -> q.freq - 10
                        "−1" -> q.freq - 1
                        "+1" -> q.freq + 1
                        else -> q.freq + 10
                    }
                    q.copy(freq = f.coerceIn(20.0, 20000.0))
                }
                syncRows()
            }
            fine.addView(b, lp)
        }
        cardFreq.addView(fine)
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(ctx)
        chips.setPadding(dp(16), 0, dp(8), dp(14))
        val quick = listOf(40.0, 100.0, 261.63, 432.0, 440.0, 528.0, 1000.0, 4000.0, 10000.0, 15000.0, 17000.0)
        for (f in quick) {
            chips.addView(W.chip(ctx, quickLabel(f)) {
                upd { it.copy(freq = f) }
                syncRows()
            })
        }
        hs.addView(chips)
        cardFreq.addView(hs)
        root.addView(cardFreq)

        // ---- sweep ----
        titled("sweep", str(R.string.sec_sweep), root)
        cardSweep = W.card(ctx)
        cardSweep.addView(row(str(R.string.p_sweep_start), 20.0, 20000.0, true, { Fmt.hz(it) }, { p().sweepStart }, { v -> upd { it.copy(sweepStart = v) } }))
        cardSweep.addView(W.divider(ctx))
        cardSweep.addView(row(str(R.string.p_sweep_end), 20.0, 20000.0, true, { Fmt.hz(it) }, { p().sweepEnd }, { v -> upd { it.copy(sweepEnd = v) } }))
        cardSweep.addView(W.divider(ctx))
        cardSweep.addView(row(str(R.string.p_sweep_time), 1.0, 600.0, true, { fmtDur(it) }, { p().sweepSec }, { v -> upd { it.copy(sweepSec = v) } }, unit = "s"))
        cardSweep.addView(W.divider(ctx))
        curveSeg = Segmented(ctx, arr(R.array.sweep_curve), if (p().sweepLog) 0 else 1) { i -> upd { it.copy(sweepLog = i == 0) } }
        cardSweep.addView(W.segRow(ctx, str(R.string.p_sweep_curve), curveSeg))
        repeatSeg = Segmented(ctx, arr(R.array.sweep_repeat), p().sweepRepeat) { i -> upd { it.copy(sweepRepeat = i) } }
        cardSweep.addView(W.segRow(ctx, str(R.string.p_sweep_repeat), repeatSeg))
        root.addView(cardSweep)

        // ---- binaurale ----
        titled("beat", str(R.string.sec_binaural), root)
        cardBeat = W.card(ctx)
        cardBeat.addView(row(str(R.string.p_beat), 0.5, 40.0, true, { "%.1f Hz".format(it) }, { p().beat }, { v -> upd { it.copy(beat = v) } }))
        val hs2 = HorizontalScrollView(ctx)
        hs2.isHorizontalScrollBarEnabled = false
        val bands = LinearLayout(ctx)
        bands.setPadding(dp(16), dp(4), dp(8), dp(8))
        for ((name, hz) in listOf("Delta" to 2.0, "Theta" to 6.0, "Alpha" to 10.0, "Beta" to 20.0, "Gamma" to 40.0)) {
            bands.addView(W.chip(ctx, "$name · ${hz.toInt()} Hz") {
                upd { it.copy(beat = hz) }
                syncRows()
            })
        }
        hs2.addView(bands)
        cardBeat.addView(hs2)
        cardBeat.addView(Ui.label(ctx, str(R.string.binaural_hint), 13f, Ui.secondary(ctx)).also { it.setPadding(dp(16), 0, dp(16), dp(14)) })
        root.addView(cardBeat)

        // ---- rumore ----
        titled("noise", str(R.string.sec_noise), root)
        cardNoise = W.card(ctx)
        noiseSeg = Segmented(ctx, arr(R.array.noise_names), p().noise) { i -> upd { it.copy(noise = i) } }
        cardNoise.addView(W.segRow(ctx, "", noiseSeg))
        root.addView(cardNoise)

        // ---- forma d'onda ----
        titled("wave", str(R.string.sec_wave), root)
        cardWave = W.card(ctx)
        waveSeg = Segmented(ctx, arr(R.array.wave_short), p().wave) { i -> upd { it.copy(wave = i) } }
        cardWave.addView(W.segRow(ctx, "", waveSeg))
        root.addView(cardWave)

        // ---- uscita ----
        titled("level", str(R.string.sec_level), root)
        val cardLevel = W.card(ctx)
        cardLevel.addView(
            row(str(R.string.p_volume), 0.0, 1.0, false, { Fmt.db(Patch(volume = it.toFloat()).db()) },
                { p().volume.toDouble() }, { v -> upd { it.copy(volume = v.toFloat()) } },
                toEdit = { Patch(volume = it.toFloat()).db().coerceAtLeast(-60.0) },
                fromEdit = { Level.fromDb(it).toDouble() }, unit = "dB")
        )
        cardLevel.addView(W.divider(ctx))
        chanSeg = Segmented(ctx, arr(R.array.channel_names), p().channel) { i -> upd { it.copy(channel = i) } }
        cardLevel.addView(W.segRow(ctx, str(R.string.p_channel), chanSeg))
        cardLevel.addView(W.divider(ctx))
        tvTimer = Ui.label(ctx, "", 16f, Ui.primary(ctx), true)
        val timerRow = LinearLayout(ctx)
        timerRow.gravity = Gravity.CENTER_VERTICAL
        timerRow.setPadding(dp(16), dp(14), dp(16), dp(14))
        timerRow.addView(Ui.label(ctx, str(R.string.p_timer), 16f, Ui.text(ctx)), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        timerRow.addView(tvTimer)
        timerRow.setOnClickListener { Ui.tap(it); timerSheet() }
        cardLevel.addView(timerRow)
        root.addView(cardLevel)

        // ---- AM ----
        titled("am", str(R.string.sec_am), root)
        val cardAm = W.card(ctx)
        swAm = MaterialSwitch(ctx)
        cardAm.addView(switchHeader(str(R.string.sec_am), swAm) { on -> upd { it.copy(amOn = on) }; refresh() })
        amBody = LinearLayout(ctx)
        amBody.orientation = LinearLayout.VERTICAL
        amBody.addView(row(str(R.string.p_rate), 0.1, 50.0, true, { "%.1f Hz".format(it) }, { p().amRate }, { v -> upd { it.copy(amRate = v) } }))
        amBody.addView(row(str(R.string.p_depth), 0.0, 1.0, false, { "%d %%".format((it * 100).toInt()) },
            { p().amDepth.toDouble() }, { v -> upd { it.copy(amDepth = v.toFloat()) } },
            toEdit = { it * 100 }, fromEdit = { it / 100 }, unit = "%"))
        cardAm.addView(amBody)
        root.addView(cardAm)

        // ---- FM ----
        titled("fm", str(R.string.sec_fm), root)
        val cardFm = W.card(ctx)
        swFm = MaterialSwitch(ctx)
        cardFm.addView(switchHeader(str(R.string.sec_fm), swFm) { on -> upd { it.copy(fmOn = on) }; refresh() })
        fmBody = LinearLayout(ctx)
        fmBody.orientation = LinearLayout.VERTICAL
        fmBody.addView(row(str(R.string.p_rate), 0.1, 50.0, true, { "%.1f Hz".format(it) }, { p().fmRate }, { v -> upd { it.copy(fmRate = v) } }))
        fmBody.addView(row(str(R.string.p_dev), 1.0, 2000.0, true, { "± %.0f Hz".format(it) }, { p().fmDev }, { v -> upd { it.copy(fmDev = v) } }, unit = "Hz"))
        cardFm.addView(fmBody)
        root.addView(cardFm)

        // le schede AM/FM hanno già l'interruttore: i titoli sopra sono superflui
        titles["am"]?.visibility = View.GONE
        titles["fm"]?.visibility = View.GONE
        refresh()
    }

    private fun trimNum(x: Double): String =
        "%.2f".format(x).trimEnd('0').trimEnd('.', ',')

    private fun quickLabel(f: Double): String = if (f >= 1000) trimNum(f / 1000.0) + " kHz" else trimNum(f) + " Hz"

    private fun fmtDur(sec: Double): String {
        val s = sec.toInt()
        return if (s < 60) ctx.getString(R.string.fmt_sec, s)
        else if (s % 60 == 0) ctx.getString(R.string.fmt_min, s / 60)
        else ctx.getString(R.string.fmt_min, s / 60) + " " + ctx.getString(R.string.fmt_sec, s % 60)
    }

    private fun switchHeader(title: String, sw: MaterialSwitch, onChange: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(ctx)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(10), dp(16), dp(10))
        r.addView(Ui.label(ctx, title, 16f, Ui.text(ctx)), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(sw)
        sw.setOnClickListener { Ui.tap(it); onChange(sw.isChecked) }
        return r
    }

    private fun buildHero(root: LinearLayout) {
        val hero = W.card(ctx)
        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(20), dp(18), dp(20), dp(18))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        tvFreq = Ui.label(ctx, "", 34f, Ui.text(ctx), true)
        tvFreq.maxLines = 1
        tvNote = Ui.label(ctx, "", 16f, Ui.primary(ctx), true)
        tvStatus = Ui.label(ctx, "", 13.5f, Ui.secondary(ctx))
        tvStatus.setPadding(0, dp(4), 0, 0)
        col.addView(tvFreq)
        col.addView(tvNote)
        col.addView(tvStatus)
        top.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        btnPlay = TextView(ctx)
        btnPlay.textSize = 24f
        btnPlay.gravity = Gravity.CENTER
        btnPlay.setTextColor(Ui.onPrimary(ctx))
        btnPlay.background = Ui.ovalBg(Ui.primary(ctx))
        val lp = LinearLayout.LayoutParams(dp(68), dp(68))
        lp.marginStart = dp(12)
        top.addView(btnPlay, lp)
        btnPlay.setOnClickListener { Ui.tap(it); act.togglePlay() }
        hero.addView(top)
        root.addView(hero)
    }

    private fun timerSheet() {
        val sheet = BottomSheetDialog(ctx)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, dp(20))
        box.addView(Ui.label(ctx, str(R.string.p_timer), 20f, Ui.text(ctx), true).also { it.setPadding(dp(24), dp(12), dp(24), dp(10)) })
        for (m in listOf(0, 1, 5, 10, 30, 60)) {
            val r = LinearLayout(ctx)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(24), dp(14), dp(24), dp(14))
            r.addView(Ui.label(ctx, Ui.fmtMinutes(ctx, m), 17f, Ui.text(ctx)), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(Ui.label(ctx, if (m == p().timerMin) "✓" else "", 20f, Ui.primary(ctx), true))
            r.setOnClickListener {
                Ui.tap(it)
                upd { q -> q.copy(timerMin = m) }
                sheet.dismiss()
                refresh()
            }
            box.addView(r)
        }
        sheet.setContentView(box)
        sheet.show()
    }

    private fun syncRows() {
        for (r in rows) r.sync()
        tick()
    }

    /** Aggiorna visibilità e valori in base al patch corrente */
    fun refresh() {
        val q = p()
        val m = q.mode
        fun vis(v: View, show: Boolean) { v.visibility = if (show) View.VISIBLE else View.GONE }
        vis(cardFreq, m == 0 || m == 2); vis(titles["freq"]!!, m == 0 || m == 2)
        vis(cardSweep, m == 1); vis(titles["sweep"]!!, m == 1)
        vis(cardBeat, m == 2); vis(titles["beat"]!!, m == 2)
        vis(cardNoise, m == 3); vis(titles["noise"]!!, m == 3)
        vis(cardWave, m != 3); vis(titles["wave"]!!, m != 3)
        swAm.isChecked = q.amOn
        swFm.isChecked = q.fmOn
        vis(amBody, q.amOn)
        vis(fmBody, q.fmOn)
        modeSeg.select(q.mode)
        waveSeg.select(q.wave); chanSeg.select(q.channel); noiseSeg.select(q.noise)
        curveSeg.select(if (q.sweepLog) 0 else 1); repeatSeg.select(q.sweepRepeat)
        tvTimer.text = Ui.fmtMinutes(ctx, q.timerMin)
        for (r in rows) r.sync()
        tick()
    }

    fun refreshStatusOnly() { tick() }

    /** Chiamato dalla schermata ogni ~100 ms e a ogni cambio di stato */
    fun tick() {
        val q = p()
        val playing = Engine.isPlaying()
        btnPlay.text = if (playing) "■" else "▶"
        val a4 = Prefs.a4(ctx)
        when (q.mode) {
            3 -> {
                tvFreq.text = arr(R.array.noise_names)[q.noise.coerceIn(0, 2)]
                tvNote.text = str(R.string.mode_noise)
            }
            1 -> {
                val f = if (playing) Engine.core.currentFreq else q.sweepStart
                tvFreq.text = Fmt.hz(f)
                tvNote.text = Notes.describe(f, a4)
            }
            2 -> {
                tvFreq.text = Fmt.hz(q.freq)
                tvNote.text = "L ${Fmt.hz(q.freq)} · R ${Fmt.hz(q.freq + q.beat)}"
            }
            else -> {
                tvFreq.text = Fmt.hz(q.freq)
                tvNote.text = Notes.describe(q.freq, a4) + " · " + arr(R.array.wave_names)[q.wave.coerceIn(0, 3)]
            }
        }
        val rem = Engine.remainingMs()
        tvStatus.text = when {
            playing && rem >= 0 -> str(R.string.hero_left).format(Ui.fmtCountdown(rem))
            playing -> str(R.string.hero_playing)
            else -> str(R.string.hero_ready)
        } + "  ·  " + Fmt.db(q.db())
    }
}
