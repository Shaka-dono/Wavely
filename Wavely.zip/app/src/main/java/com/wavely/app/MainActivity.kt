package com.wavely.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var gen: GeneratorPage
    private lateinit var spec: SpectrumPage
    private lateinit var pre: PresetsPage
    private lateinit var chl: ChladniPage
    private val tabViews = ArrayList<TextView>()
    private var tab = 0
    private var appliedAccent = ""
    private var askedNotif = false
    private var micCallback: ((Boolean) -> Unit)? = null

    private val listener: () -> Unit = { gen.refreshStatusOnly(); updateScreenFlag() }

    private val ticker = object : Runnable {
        override fun run() {
            gen.tick()
            handler.postDelayed(this, 120)
        }
    }

    private val specTicker = object : Runnable {
        override fun run() {
            if (tab == 1) {
                spec.frame()
                handler.postDelayed(this, 33)
            } else if (tab == 3) {
                chl.frame()
                handler.postDelayed(this, 33)
            }
        }
    }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startPlay() }

    private val micPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (!ok) Toast.makeText(this, R.string.mic_denied, Toast.LENGTH_LONG).show()
            micCallback?.invoke(ok)
            micCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)
        appliedAccent = Prefs.accent(this)
        Engine.load(this)
        buildUi()
        showTab(Prefs.lastTab(this).coerceIn(0, 3))
    }

    override fun onResume() {
        super.onResume()
        if (appliedAccent != Prefs.accent(this)) {
            recreate()
            return
        }
        Engine.addListener(listener)
        gen.refresh()
        handler.post(ticker)
        if (tab == 1 || tab == 3) {
            if (tab == 1) spec.onShown() else chl.onShown()
            handler.post(specTicker)
        }
        updateScreenFlag()
    }

    override fun onPause() {
        super.onPause()
        Engine.removeListener(listener)
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(specTicker)
        spec.onHidden()
        chl.onHidden()
        Engine.savePatch(this)
        Prefs.sp(this).edit().putInt("tab", tab).apply()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(20), dp(10), dp(16), dp(8))
        header.addView(Ui.label(this, getString(R.string.app_name), 32f, Ui.text(this), true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = TextView(this)
        gear.text = "⚙️"
        gear.textSize = 20f
        gear.gravity = Gravity.CENTER
        gear.setBackgroundResource(R.drawable.bg_circle_btn)
        gear.setOnClickListener { Ui.tap(it); startActivity(Intent(this, SettingsActivity::class.java)) }
        header.addView(gear, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(header)

        val content = FrameLayout(this)
        gen = GeneratorPage(this)
        spec = SpectrumPage(this)
        pre = PresetsPage(this)
        chl = ChladniPage(this)
        content.addView(gen)
        content.addView(spec)
        content.addView(pre)
        content.addView(chl)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // barra inferiore
        val bar = LinearLayout(this)
        bar.setBackgroundColor(Ui.surface(this))
        bar.setPadding(dp(8), dp(6), dp(8), dp(8))
        val items = listOf("🎛️" to R.string.tab_generate, "📊" to R.string.tab_spectrum, "⭐" to R.string.tab_presets, "🌀" to R.string.tab_chladni)
        for ((i, entry) in items.withIndex()) {
            val t = TextView(this)
            t.text = entry.first + "\n" + getString(entry.second)
            t.textSize = 12f
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(6), 0, dp(6))
            t.setOnClickListener { v -> Ui.tap(v); showTab(i) }
            bar.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            tabViews.add(t)
        }
        root.addView(bar)
        setContentView(root)
    }

    fun showTab(i: Int) {
        tab = i
        gen.visibility = if (i == 0) View.VISIBLE else View.GONE
        spec.visibility = if (i == 1) View.VISIBLE else View.GONE
        pre.visibility = if (i == 2) View.VISIBLE else View.GONE
        chl.visibility = if (i == 3) View.VISIBLE else View.GONE
        for ((k, t) in tabViews.withIndex()) {
            t.setTextColor(if (k == i) Ui.primary(this) else Ui.secondary(this))
            t.alpha = if (k == i) 1f else 0.85f
        }
        handler.removeCallbacks(specTicker)
        spec.onHidden()
        chl.onHidden()
        if (i == 1) {
            spec.onShown()
            handler.post(specTicker)
        } else if (i == 3) {
            chl.onShown()
            handler.post(specTicker)
        }
        if (i == 0) gen.refresh()
        if (i == 2) pre.rebuild()
        updateScreenFlag()
    }

    private fun updateScreenFlag() {
        val keep = Prefs.keepScreen(this) && (tab == 1 || tab == 3 || Engine.isPlaying())
        if (keep) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---- riproduzione ----

    fun togglePlay() {
        if (Engine.isPlaying()) {
            ToneService.stop()
            return
        }
        val p = Engine.patch
        if (Prefs.hearingGuard(this) && p.db() > -12.0) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.warn_title)
                .setMessage(R.string.warn_msg)
                .setPositiveButton(R.string.warn_continue) { _, _ -> checkNotifThenPlay() }
                .setNegativeButton(R.string.warn_lower) { _, _ ->
                    Engine.update(this) { it.copy(volume = Level.fromDb(-24.0)) }
                    gen.refresh()
                    checkNotifThenPlay()
                }
                .show()
        } else {
            checkNotifThenPlay()
        }
    }

    private fun checkNotifThenPlay() {
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startPlay()
        }
    }

    private fun startPlay() {
        ToneService.play(this)
    }

    // ---- microfono ----

    fun requestMic(cb: (Boolean) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            cb(true)
        } else {
            micCallback = cb
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun micOn() { if ((spec.useMic && tab == 1) || (chl.useMic && tab == 3)) Mic.start() }
    fun micOff() { Mic.stop() }
}
