package com.wavely.app

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import org.json.JSONArray
import org.json.JSONObject

class SavedPreset(val name: String, val patch: Patch)

object Prefs {
    fun sp(c: Context): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(c)

    fun accent(c: Context): String = sp(c).getString("accent", "teal") ?: "teal"
    fun a4(c: Context): Double = (sp(c).getString("a4", "440") ?: "440").toDoubleOrNull() ?: 440.0
    fun floorDb(c: Context): Double = (sp(c).getString("floor_db", "-90") ?: "-90").toDoubleOrNull() ?: -90.0
    fun keepScreen(c: Context): Boolean = sp(c).getBoolean("keep_screen", true)
    fun hearingGuard(c: Context): Boolean = sp(c).getBoolean("hearing_guard", true)
    fun lastTab(c: Context): Int = sp(c).getInt("tab", 0)

    // ---- patch <-> JSON ----
    fun toJson(p: Patch): JSONObject = JSONObject().apply {
        put("mode", p.mode); put("wave", p.wave); put("freq", p.freq); put("volume", p.volume.toDouble())
        put("channel", p.channel); put("sweepStart", p.sweepStart); put("sweepEnd", p.sweepEnd)
        put("sweepSec", p.sweepSec); put("sweepLog", p.sweepLog); put("sweepRepeat", p.sweepRepeat)
        put("beat", p.beat); put("noise", p.noise); put("amOn", p.amOn); put("amRate", p.amRate)
        put("amDepth", p.amDepth.toDouble()); put("fmOn", p.fmOn); put("fmRate", p.fmRate)
        put("fmDev", p.fmDev); put("timerMin", p.timerMin)
    }

    fun fromJson(o: JSONObject): Patch {
        val d = Patch()
        return Patch(
            mode = o.optInt("mode", d.mode), wave = o.optInt("wave", d.wave),
            freq = o.optDouble("freq", d.freq), volume = o.optDouble("volume", d.volume.toDouble()).toFloat(),
            channel = o.optInt("channel", d.channel),
            sweepStart = o.optDouble("sweepStart", d.sweepStart), sweepEnd = o.optDouble("sweepEnd", d.sweepEnd),
            sweepSec = o.optDouble("sweepSec", d.sweepSec), sweepLog = o.optBoolean("sweepLog", d.sweepLog),
            sweepRepeat = o.optInt("sweepRepeat", d.sweepRepeat),
            beat = o.optDouble("beat", d.beat), noise = o.optInt("noise", d.noise),
            amOn = o.optBoolean("amOn", d.amOn), amRate = o.optDouble("amRate", d.amRate),
            amDepth = o.optDouble("amDepth", d.amDepth.toDouble()).toFloat(),
            fmOn = o.optBoolean("fmOn", d.fmOn), fmRate = o.optDouble("fmRate", d.fmRate),
            fmDev = o.optDouble("fmDev", d.fmDev), timerMin = o.optInt("timerMin", 0)
        )
    }

    fun savePatch(c: Context, p: Patch) {
        sp(c).edit().putString("patch", toJson(p).toString()).apply()
    }

    fun loadPatch(c: Context): Patch = try {
        fromJson(JSONObject(sp(c).getString("patch", "{}") ?: "{}"))
    } catch (e: Exception) {
        Patch()
    }

    // ---- preset dell'utente ----
    fun presets(c: Context): MutableList<SavedPreset> {
        val out = mutableListOf<SavedPreset>()
        try {
            val arr = JSONArray(sp(c).getString("presets", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(SavedPreset(o.getString("name"), fromJson(o.getJSONObject("patch"))))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun savePresets(c: Context, list: List<SavedPreset>) {
        val arr = JSONArray()
        for (p in list) arr.put(JSONObject().put("name", p.name).put("patch", toJson(p.patch)))
        sp(c).edit().putString("presets", arr.toString()).apply()
    }
}
