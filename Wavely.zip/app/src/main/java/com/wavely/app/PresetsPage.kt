package com.wavely.app

import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Pagina "Preset": suoni già pronti e quelli salvati dall'utente. */
class PresetsPage(private val act: MainActivity) : ScrollView(act) {

    private val ctx = act
    private val root = LinearLayout(ctx)

    private class Ready(val nameRes: Int, val patch: Patch)

    private val ready = listOf(
        Ready(R.string.pre_a440, Patch(freq = 440.0)),
        Ready(R.string.pre_a432, Patch(freq = 432.0)),
        Ready(R.string.pre_528, Patch(freq = 528.0)),
        Ready(R.string.pre_1k, Patch(freq = 1000.0)),
        Ready(R.string.pre_sub, Patch(freq = 40.0, volume = 0.55f)),
        Ready(R.string.pre_hf, Patch(freq = 15000.0, volume = 0.45f)),
        Ready(R.string.pre_sweep, Patch(mode = 1, sweepStart = 20.0, sweepEnd = 20000.0, sweepSec = 30.0, volume = 0.5f)),
        Ready(R.string.pre_delta, Patch(mode = 2, freq = 150.0, beat = 2.0, volume = 0.5f)),
        Ready(R.string.pre_theta, Patch(mode = 2, freq = 200.0, beat = 6.0, volume = 0.5f)),
        Ready(R.string.pre_alpha, Patch(mode = 2, freq = 250.0, beat = 10.0, volume = 0.5f)),
        Ready(R.string.pre_pink, Patch(mode = 3, noise = 1, volume = 0.6f)),
        Ready(R.string.pre_tremolo, Patch(freq = 440.0, amOn = true, amRate = 4.0, amDepth = 0.7f)),
        Ready(R.string.pre_siren, Patch(freq = 900.0, fmOn = true, fmRate = 0.8, fmDev = 400.0))
    )

    private fun dp(v: Int) = Ui.dp(ctx, v)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(4), dp(16), dp(24))
        addView(root)
        rebuild()
    }

    private fun load(p: Patch) {
        val keepTimer = Engine.patch.timerMin
        Engine.update(ctx) { p.copy(timerMin = keepTimer) }
        act.showTab(0)
    }

    private fun item(name: String, p: Patch, onLong: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dp(20), dp(13), dp(20), dp(13))
        r.addView(Ui.label(ctx, name, 17f, Ui.text(ctx)))
        r.addView(Ui.label(ctx, ToneService.describe(ctx, p) + "  ·  " + Fmt.db(p.db()), 13f, Ui.secondary(ctx)))
        val tv = android.util.TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        r.setBackgroundResource(tv.resourceId)
        r.setOnClickListener { Ui.tap(it); load(p) }
        if (onLong != null) r.setOnLongClickListener { onLong(); true }
        return r
    }

    fun rebuild() {
        root.removeAllViews()
        val save = Ui.label(ctx, ctx.getString(R.string.pre_save), 16f, Ui.onPrimary(ctx), true)
        save.gravity = Gravity.CENTER
        save.setPadding(dp(16), dp(15), dp(16), dp(15))
        save.background = Ui.roundBg(ctx, Ui.primary(ctx), 18)
        save.setOnClickListener { Ui.tap(it); saveDialog() }
        root.addView(save, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(W.title(ctx, ctx.getString(R.string.pre_mine)))
        val mine = Prefs.presets(ctx)
        val c1 = W.card(ctx)
        if (mine.isEmpty()) {
            c1.addView(Ui.label(ctx, ctx.getString(R.string.pre_empty), 14.5f, Ui.secondary(ctx)).also { it.setPadding(dp(20), dp(16), dp(20), dp(16)) })
        } else {
            for ((i, m) in mine.withIndex()) {
                if (i > 0) c1.addView(W.divider(ctx))
                c1.addView(item(m.name, m.patch) { confirmDelete(i, m.name) })
            }
            c1.addView(Ui.label(ctx, ctx.getString(R.string.pre_hold_hint), 12.5f, Ui.secondary(ctx)).also { it.setPadding(dp(20), dp(2), dp(20), dp(12)) })
        }
        root.addView(c1)

        root.addView(W.title(ctx, ctx.getString(R.string.pre_builtin)))
        val c2 = W.card(ctx)
        for ((i, r) in ready.withIndex()) {
            if (i > 0) c2.addView(W.divider(ctx))
            c2.addView(item(ctx.getString(r.nameRes), r.patch, null))
        }
        root.addView(c2)
    }

    private fun confirmDelete(i: Int, name: String) {
        MaterialAlertDialogBuilder(ctx)
            .setTitle(ctx.getString(R.string.pre_delete_title, name))
            .setPositiveButton(R.string.btn_delete) { _, _ ->
                val l = Prefs.presets(ctx)
                if (i < l.size) l.removeAt(i)
                Prefs.savePresets(ctx, l)
                rebuild()
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun saveDialog() {
        val et = EditText(ctx)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.hint = ctx.getString(R.string.pre_name_hint)
        et.setSingleLine()
        val wrap = LinearLayout(ctx)
        wrap.setPadding(dp(24), dp(8), dp(24), 0)
        wrap.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.pre_name_title)
            .setView(wrap)
            .setPositiveButton(R.string.btn_save) { _, _ ->
                val name = et.text.toString().trim().ifEmpty { ctx.getString(R.string.pre_default_name) }
                val l = Prefs.presets(ctx)
                l.add(SavedPreset(name, Engine.patch.copy(timerMin = 0)))
                Prefs.savePresets(ctx, l)
                rebuild()
                Toast.makeText(ctx, R.string.pre_saved, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }
}
