package com.wavely.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Shader
import android.view.View

/** Barre dello spettro in scala logaritmica 20 Hz–20 kHz con picchi che restano un attimo. */
class SpectrumView(context: Context, private val sp: Spectrum) : View(context) {

    var floorDb = -90.0
    var markerHz = 0.0
    private val d = resources.displayMetrics.density
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val grid = Paint().apply { color = Ui.outline(context); strokeWidth = 1f }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.secondary(context); textSize = 10.5f * d
    }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.text(context); strokeWidth = 1.2f * d; alpha = 140
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(5 * d, 4 * d), 0f)
    }
    private val accent = Ui.primary(context)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val top = Color.argb(255, Color.red(accent), Color.green(accent), Color.blue(accent))
        val bot = Color.argb(60, Color.red(accent), Color.green(accent), Color.blue(accent))
        bar.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bot, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val padB = 20f * d
        val plotH = h - padB
        // linee orizzontali ogni 20 dB
        var db = 0.0
        while (db > floorDb + 1) {
            val y = plotH * (1f - ((db - floorDb) / -floorDb).toFloat())
            c.drawLine(0f, y, w, y, grid)
            c.drawText("%d".format(db.toInt()), 3f * d, y - 3f * d, label)
            db -= 20.0
        }
        // linee verticali alle decadi
        for ((f, t) in listOf(50.0 to "50", 100.0 to "100", 200.0 to "200", 500.0 to "500", 1000.0 to "1k", 2000.0 to "2k", 5000.0 to "5k", 10000.0 to "10k", 20000.0 to "20k")) {
            val x = sp.posOf(f) * w
            c.drawLine(x, 0f, x, plotH, grid)
            val tw = label.measureText(t)
            c.drawText(t, (x - tw / 2f).coerceIn(0f, w - tw), h - 5f * d, label)
        }
        val n = sp.bands
        val bw = w / n
        for (i in 0 until n) {
            val v = sp.level[i]
            val x = i * bw
            if (v > 0.002f) {
                c.drawRect(x + 0.6f * d, plotH * (1f - v), x + bw - 0.6f * d, plotH, bar)
            }
            val pk = sp.peak[i]
            if (pk > 0.01f) c.drawRect(x + 0.6f * d, plotH * (1f - pk) - 2f * d, x + bw - 0.6f * d, plotH * (1f - pk), cap)
        }
        if (markerHz in 20.0..20000.0) {
            val x = sp.posOf(markerHz) * w
            c.drawLine(x, 0f, x, plotH, mark)
        }
    }
}

/** Oscilloscopio con aggancio sul fronte di salita. */
class ScopeView(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    val data = FloatArray(1024)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.primary(context); strokeWidth = 2f * d; style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val grid = Paint().apply { color = Ui.outline(context); strokeWidth = 1f }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawLine(0f, h / 2f, w, h / 2f, grid)
        c.drawLine(0f, h * 0.25f, w, h * 0.25f, grid)
        c.drawLine(0f, h * 0.75f, w, h * 0.75f, grid)
        // aggancio: primo passaggio per zero in salita nella prima metà
        var start = 0
        for (i in 1 until 512) {
            if (data[i - 1] < 0f && data[i] >= 0f) { start = i; break }
        }
        val n = 512
        // normalizzazione automatica morbida: ingrandisce i segnali piccoli fino a 8x
        var peak = 0f
        for (i in 0 until n) peak = maxOf(peak, kotlin.math.abs(data[start + i]))
        val gain = if (peak < 0.004f) 1f else (0.9f / peak).coerceIn(1f, 8f)
        path.reset()
        for (i in 0 until n) {
            val x = w * i / (n - 1)
            val y = h / 2f - data[start + i] * gain * h * 0.46f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, line)
    }
}
