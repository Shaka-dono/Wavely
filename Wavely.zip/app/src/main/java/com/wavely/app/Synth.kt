package com.wavely.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

const val SR = 44100.0
private const val TWO_PI = 2.0 * PI

/** Tutti i parametri del suono. Immutabile: l'interfaccia ne crea una copia, il motore la legge. */
data class Patch(
    val mode: Int = 0,            // 0 tono, 1 sweep, 2 binaurale, 3 rumore
    val wave: Int = 0,            // 0 seno, 1 quadra, 2 triangolare, 3 dente di sega
    val freq: Double = 440.0,
    val volume: Float = 0.6f,     // 0..1 sul cursore (0 = muto, 1 = 0 dBFS, 0.0166 per dB)
    val channel: Int = 0,         // 0 stereo, 1 sinistra, 2 destra
    val sweepStart: Double = 20.0,
    val sweepEnd: Double = 20000.0,
    val sweepSec: Double = 30.0,
    val sweepLog: Boolean = true,
    val sweepRepeat: Int = 0,     // 0 una volta, 1 ciclo, 2 avanti e indietro
    val beat: Double = 10.0,      // differenza Hz tra orecchio destro e sinistro
    val noise: Int = 1,           // 0 bianco, 1 rosa, 2 marrone
    val amOn: Boolean = false,
    val amRate: Double = 4.0,
    val amDepth: Float = 0.5f,
    val fmOn: Boolean = false,
    val fmRate: Double = 5.0,
    val fmDev: Double = 50.0,
    val timerMin: Int = 0
) {
    /** ampiezza lineare da 0 a 1 */
    fun amplitude(): Double =
        if (volume <= 0.001f) 0.0 else 10.0.pow(-60.0 * (1.0 - volume) / 20.0)

    fun db(): Double = if (volume <= 0.001f) -120.0 else -60.0 * (1.0 - volume)
}

object Level {
    fun fromDb(db: Double): Float = (1.0 + db / 60.0).coerceIn(0.0, 1.0).toFloat()
}

class Rand(seed: Int) {
    private var x = if (seed == 0) 88172645 else seed
    fun w(): Double {
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        return x / 2147483648.0
    }
}

private class Noise(seed: Int) {
    private val r = Rand(seed * 7919 + 13)
    private var b0 = 0.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var br = 0.0
    fun next(type: Int): Double {
        val w = r.w()
        return when (type) {
            0 -> w * 0.5
            1 -> {
                b0 = 0.99765 * b0 + w * 0.0990460
                b1 = 0.96300 * b1 + w * 0.2965164
                b2 = 0.57000 * b2 + w * 1.0526913
                (b0 + b1 + b2 + w * 0.1848) * 0.17
            }
            else -> {
                br = (br + 0.02 * w) / 1.02
                br * 5.0
            }
        }
    }
}

/**
 * Cuore del generatore (senza Android, testabile): produce blocchi stereo.
 * Seno esatto; quadra e dente di sega con correzione PolyBLEP contro l'aliasing.
 */
class SynthCore {
    private var phL = 0.0
    private var phR = 0.0
    private var phAm = 0.0
    private var phFm = 0.0
    private var fCur = 440.0
    private var ampCur = 0.0
    private var env = 0.0
    private var sweepP = 0.0
    private var sweepDir = 1
    private val nL = Noise(1)
    private val nR = Noise(2)

    @Volatile var currentFreq = 440.0
    @Volatile var finished = false
    @Volatile var running = false

    fun reset() {
        sweepP = 0.0
        sweepDir = 1
        finished = false
        phAm = 0.0
        phFm = 0.0
    }

    fun isSilent(): Boolean = !running && env <= 0.0001

    private fun blep(t: Double, dt: Double): Double {
        if (t < dt) {
            val x = t / dt
            return x + x - x * x - 1.0
        }
        if (t > 1.0 - dt) {
            val x = (t - 1.0) / dt
            return x * x + x + x + 1.0
        }
        return 0.0
    }

    private fun osc(ph: Double, dt: Double, wave: Int): Double = when (wave) {
        0 -> sin(TWO_PI * ph)
        1 -> {
            var v = if (ph < 0.5) 1.0 else -1.0
            v += blep(ph, dt)
            v -= blep((ph + 0.5) % 1.0, dt)
            v * 0.7071
        }
        2 -> if (ph < 0.5) 4.0 * ph - 1.0 else 3.0 - 4.0 * ph
        else -> (2.0 * ph - 1.0) - blep(ph, dt)
    }

    private fun sweepFreq(p: Patch, x: Double): Double {
        val a = p.sweepStart.coerceAtLeast(1.0)
        val b = p.sweepEnd.coerceAtLeast(1.0)
        return if (p.sweepLog) a * (b / a).pow(x) else a + (b - a) * x
    }

    fun render(p: Patch, outL: FloatArray, outR: FloatArray, n: Int) {
        val ampT = p.amplitude()
        val glide = 1.0 - exp(-1.0 / (0.008 * SR))
        val ampK = 1.0 - exp(-1.0 / (0.012 * SR))
        val envStep = 1.0 / (0.03 * SR)
        val target = when (p.mode) {
            1 -> -1.0
            else -> p.freq
        }
        val sweepStep = 1.0 / (p.sweepSec.coerceAtLeast(0.5) * SR)
        val limit = SR * 0.49
        val chanL = if (p.channel == 2) 0.0 else 1.0
        val chanR = if (p.channel == 1) 0.0 else 1.0

        for (i in 0 until n) {
            // frequenza portante
            val fTarget = if (target < 0) {
                if (running && !finished) {
                    sweepP += sweepStep * sweepDir
                    when (p.sweepRepeat) {
                        0 -> if (sweepP >= 1.0) { sweepP = 1.0; finished = true }
                        1 -> if (sweepP >= 1.0) sweepP -= 1.0
                        else -> {
                            if (sweepP >= 1.0) { sweepP = 1.0; sweepDir = -1 }
                            if (sweepP <= 0.0) { sweepP = 0.0; sweepDir = 1 }
                        }
                    }
                }
                sweepFreq(p, sweepP)
            } else target
            fCur = if (target < 0) fTarget else fCur + (fTarget - fCur) * glide
            currentFreq = fCur

            // modulazione di frequenza
            var f = fCur
            if (p.fmOn) {
                phFm += TWO_PI * p.fmRate / SR
                if (phFm > TWO_PI) phFm -= TWO_PI
                f += p.fmDev * sin(phFm)
            }
            if (f < 1.0) f = 1.0
            if (f > limit) f = limit
            var fR = f
            if (p.mode == 2) fR = (f + p.beat).coerceIn(1.0, limit)

            // oscillatori
            var l: Double
            var r: Double
            if (p.mode == 3) {
                l = nL.next(p.noise)
                r = nR.next(p.noise)
            } else {
                phL += f / SR
                if (phL >= 1.0) phL -= 1.0
                phR += fR / SR
                if (phR >= 1.0) phR -= 1.0
                l = osc(phL, f / SR, p.wave)
                r = if (p.mode == 2) osc(phR, fR / SR, p.wave) else osc(phL, f / SR, p.wave)
            }

            // modulazione di ampiezza
            if (p.amOn) {
                phAm += TWO_PI * p.amRate / SR
                if (phAm > TWO_PI) phAm -= TWO_PI
                val g = 1.0 - p.amDepth * (0.5 + 0.5 * sin(phAm))
                l *= g
                r *= g
            }

            // volume e inviluppo di avvio/arresto (niente click)
            ampCur += (ampT - ampCur) * ampK
            env = if (running && !finished) minOf(1.0, env + envStep) else maxOf(0.0, env - envStep)
            val g = ampCur * env
            l = (l * g * chanL).coerceIn(-1.0, 1.0)
            r = (r * g * chanR).coerceIn(-1.0, 1.0)
            outL[i] = l.toFloat()
            outR[i] = r.toFloat()
        }
    }
}

/** Buffer circolare degli ultimi campioni, letto da spettro e oscilloscopio. */
class Ring(val size: Int = 8192) {
    private val buf = FloatArray(size)
    @Volatile private var pos = 0

    fun write(src: FloatArray, n: Int) {
        var p = pos
        for (i in 0 until n) {
            buf[p] = src[i]
            p++
            if (p == size) p = 0
        }
        pos = p
    }

    fun write(src: FloatArray, n: Int, src2: FloatArray) {
        var p = pos
        for (i in 0 until n) {
            buf[p] = (src[i] + src2[i]) * 0.5f
            p++
            if (p == size) p = 0
        }
        pos = p
    }

    /** copia gli ultimi `count` campioni (in ordine di tempo) */
    fun latest(dst: FloatArray, count: Int) {
        var p = pos - count
        if (p < 0) p += size
        for (i in 0 until count) {
            dst[i] = buf[p]
            p++
            if (p == size) p = 0
        }
    }

    fun clear() {
        java.util.Arrays.fill(buf, 0f)
    }
}

fun levelOf(buf: FloatArray, n: Int): Float {
    var m = 0f
    for (i in 0 until n) m = maxOf(m, abs(buf[i]))
    return m
}
