package com.wavely.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle

/** Tiene vivo il generatore a schermo spento e mostra i comandi nella notifica. */
class ToneService : Service() {

    companion object {
        const val ACTION_PLAY = "com.wavely.app.PLAY"
        const val ACTION_STOP = "com.wavely.app.STOP"
        const val CHANNEL = "playback"
        const val NOTIF_ID = 21

        fun play(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, ToneService::class.java).setAction(ACTION_PLAY))
        }

        fun stop() {
            Engine.stop()
        }

        fun describe(c: Context, p: Patch): String {
            val f = if (p.freq >= 1000) "%.2f kHz".format(p.freq / 1000.0) else "%.1f Hz".format(p.freq)
            return when (p.mode) {
                1 -> c.getString(R.string.mode_sweep) + " " + Fmt.hz(p.sweepStart) + " → " + Fmt.hz(p.sweepEnd)
                2 -> c.getString(R.string.mode_binaural) + " " + f + " / +" + "%.1f Hz".format(p.beat)
                3 -> c.getString(R.string.mode_noise) + " · " + c.resources.getStringArray(R.array.noise_names)[p.noise.coerceIn(0, 2)]
                else -> f + " · " + c.resources.getStringArray(R.array.wave_names)[p.wave.coerceIn(0, 3)]
            }
        }
    }

    private lateinit var session: MediaSessionCompat
    private var wake: PowerManager.WakeLock? = null
    private var focusReq: AudioFocusRequest? = null
    private var foreground = false
    private val handler = Handler(Looper.getMainLooper())
    private var pendingNotify = false

    private val listener: () -> Unit = { onChanged() }

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) Engine.stop()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Engine.load(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        session = MediaSessionCompat(this, "Wavely")
        session.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() { if (!Engine.isPlaying()) Engine.play() }
            override fun onPause() { Engine.stop() }
            override fun onStop() { Engine.stop() }
        })
        session.isActive = true
        ContextCompat.registerReceiver(
            this, noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        Engine.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Engine.stop()
            shutdown()
        } else {
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            foreground = true
            requestFocus()
            if (wake?.isHeld != true) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Wavely:play").also { it.acquire(6 * 60 * 60 * 1000L) }
            }
            if (!Engine.isPlaying()) Engine.play()
        }
        return START_NOT_STICKY
    }

    private fun onChanged() {
        if (!Engine.isPlaying()) {
            shutdown()
            return
        }
        // la frequenza cambia di continuo mentre si muove il cursore: aggiorna la notifica al massimo ogni 0,5 s
        if (!pendingNotify && foreground) {
            pendingNotify = true
            handler.postDelayed({
                pendingNotify = false
                if (Engine.isPlaying() && foreground) {
                    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
                }
            }, 500)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, ToneService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val t = describe(this, Engine.patch)
        session.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, t)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, getString(R.string.app_name))
                .build()
        )
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_STOP)
                .setState(PlaybackStateCompat.STATE_PLAYING, 0, 1f)
                .build()
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_wave)
            .setContentTitle(t)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .addAction(R.drawable.ic_stat_wave, getString(R.string.notif_stop), stopI)
            .setStyle(MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0))
        val rem = Engine.remainingMs()
        if (rem >= 0) {
            b.setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
                .setWhen(System.currentTimeMillis() + rem)
        }
        return b.build()
    }

    private fun requestFocus() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) Engine.stop()
            }
            .build()
        focusReq = req
        am.requestAudioFocus(req)
    }

    private fun shutdown() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        focusReq = null
        if (foreground) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            foreground = false
        }
        stopSelf()
    }

    override fun onDestroy() {
        Engine.removeListener(listener)
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(noisy) } catch (e: Exception) { }
        session.isActive = false
        session.release()
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
