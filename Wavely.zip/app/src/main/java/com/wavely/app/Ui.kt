package com.wavely.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.TextView
import com.google.android.material.color.MaterialColors

object Ui {
    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun primary(c: Context): Int =
        MaterialColors.getColor(c, androidx.appcompat.R.attr.colorPrimary, Color.WHITE)

    fun onPrimary(c: Context): Int =
        MaterialColors.getColor(c, com.google.android.material.R.attr.colorOnPrimary, Color.BLACK)

    fun text(c: Context): Int =
        MaterialColors.getColor(c, com.google.android.material.R.attr.colorOnSurface, Color.WHITE)

    fun secondary(c: Context): Int =
        MaterialColors.getColor(c, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)

    fun outline(c: Context): Int =
        MaterialColors.getColor(c, com.google.android.material.R.attr.colorOutlineVariant, Color.DKGRAY)

    fun surfaceVariant(c: Context): Int =
        MaterialColors.getColor(c, com.google.android.material.R.attr.colorSurfaceVariant, Color.DKGRAY)

    fun surface(c: Context): Int =
        MaterialColors.getColor(c, com.google.android.material.R.attr.colorSurface, Color.BLACK)

    fun tap(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    fun tick(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    fun roundBg(c: Context, color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, radiusDp).toFloat()
        return g
    }

    fun ovalBg(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    fun label(c: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    fun fmtMinutes(c: Context, m: Int): String {
        if (m <= 0) return c.getString(R.string.main_timer_off)
        if (m < 60) return c.getString(R.string.fmt_min, m)
        if (m % 60 == 0) return c.getString(R.string.fmt_hours, m / 60)
        return c.getString(R.string.fmt_hours, m / 60) + " " + c.getString(R.string.fmt_min, m % 60)
    }

    fun fmtSeconds(c: Context, s: Int): String =
        if (s < 60) c.getString(R.string.fmt_sec, s) else fmtMinutes(c, s / 60)

    fun fmtCountdown(ms: Long): String {
        val total = (ms + 999) / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }
}

object Fmt {
    fun hz(f: Double): String = when {
        f >= 10000 -> "%.2f kHz".format(f / 1000.0)
        f >= 1000 -> "%.3f kHz".format(f / 1000.0)
        f >= 100 -> "%.1f Hz".format(f)
        else -> "%.2f Hz".format(f)
    }

    fun db(db: Double): String = if (db <= -119) "−∞ dB" else "%.1f dB".format(db).replace('-', '−')
}
