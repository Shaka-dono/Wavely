package com.wavely.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class WavelyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        Engine.load(this)
    }
}
