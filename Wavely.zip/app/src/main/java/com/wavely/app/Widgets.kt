package com.wavely.app

import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.content.res.ColorStateList
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.ln
import kotlin.math.pow

/** Selettore a segmenti in stile iOS. */
class Segmented(
    ctx: Context, private val items: List<String>, selected: Int, private val onSelect: (Int) -> Unit
) : LinearLayout(ctx) {
    private val views = ArrayList<TextView>()
    private var sel = selected

    init {
        orientation = HORIZONTAL
        val pad = Ui.dp(ctx, 3)
        setPadding(pad, pad, pad, pad)
        background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 13)
        for ((i, s) in items.withIndex()) {
            val t = TextView(ctx)
            t.text = s
            t.textSize = 13.5f
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 10), Ui.dp(ctx, 4), Ui.dp(ctx, 10))
            t.setOnClickListener {
                Ui.tap(it)
                if (sel != i) {
                    select(i)
                    onSelect(i)
                }
            }
            addView(t, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            views.add(t)
        }
        paint()
    }

    fun select(i: Int) {
        sel = i
        paint()
    }

    private fun paint() {
        for ((i, t) in views.withIndex()) {
            if (i == sel) {
                t.background = Ui.roundBg(context, Ui.primary(context), 10)
                t.setTextColor(Ui.onPrimary(context))
                t.setTypeface(null, android.graphics.Typeface.BOLD)
            } else {
                t.background = null
                t.setTextColor(Ui.secondary(context))
                t.setTypeface(null, android.graphics.Typeface.NORMAL)
            }
        }
    }
}

/**
 * Riga con titolo, valore (toccabile per scriverlo a mano) e cursore.
 * Il cursore può essere lineare o logaritmico; "toEdit/fromEdit" permettono di digitare in un'altra unità (es. dB).
 */
class ParamRow(
    ctx: Context,
    private val title: String,
    private val min: Double,
    private val max: Double,
    private val log: Boolean,
    private val show: (Double) -> String,
    private val get: () -> Double,
    private val set: (Double) -> Unit,
    private val toEdit: (Double) -> Double = { it },
    private val fromEdit: (Double) -> Double = { it },
    private val editUnit: String = "",
    private val tint: Int? = null
) : LinearLayout(ctx) {

    private val tvValue = TextView(ctx)
    private val seek = SeekBar(ctx)
    private var updating = false

    init {
        orientation = VERTICAL
        setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 6))
        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.label(ctx, title, 16f, Ui.text(ctx)), LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tvValue.textSize = 16f
        tvValue.setTextColor(tint ?: Ui.primary(ctx))
        tvValue.setTypeface(null, android.graphics.Typeface.BOLD)
        tvValue.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4))
        tvValue.setOnClickListener { Ui.tap(it); editDialog() }
        top.addView(tvValue)
        addView(top)
        seek.max = 1000
        val c = tint ?: Ui.primary(ctx)
        seek.progressTintList = ColorStateList.valueOf(c)
        seek.thumbTintList = ColorStateList.valueOf(c)
        seek.progressBackgroundTintList = ColorStateList.valueOf(Ui.outline(ctx))
        seek.setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 4), Ui.dp(ctx, 2), 0)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser || updating) return
                val v = fromPos(p / 1000.0)
                tvValue.text = show(v)
                set(v)
            }
            override fun onStartTrackingTouch(bar: SeekBar) { Ui.tick(bar) }
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })
        addView(seek, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sync()
    }

    private fun fromPos(x: Double): Double = if (log) min * (max / min).pow(x) else min + (max - min) * x
    private fun toPos(v: Double): Double {
        val c = v.coerceIn(min, max)
        return if (log) ln(c / min) / ln(max / min) else (c - min) / (max - min)
    }

    fun sync() {
        val v = get()
        updating = true
        seek.progress = (toPos(v) * 1000).toInt()
        updating = false
        tvValue.text = show(v)
    }

    private fun editDialog() {
        val ctx = context
        val et = EditText(ctx)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        val lo = toEdit(min)
        val hi = toEdit(max)
        et.setText("%.2f".format(toEdit(get())).trimEnd('0').trimEnd('.').replace(',', '.'))
        et.setSelection(et.text.length)
        val wrap = LinearLayout(ctx)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setPadding(Ui.dp(ctx, 24), Ui.dp(ctx, 8), Ui.dp(ctx, 24), 0)
        wrap.addView(et, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val range = ctx.getString(R.string.dlg_range, trim(lo) + " " + editUnit, trim(hi) + " " + editUnit)
        wrap.addView(Ui.label(ctx, range, 13f, Ui.secondary(ctx)).also { it.setPadding(0, Ui.dp(ctx, 6), 0, 0) })
        MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton(R.string.btn_ok) { _, _ ->
                val x = et.text.toString().replace(',', '.').toDoubleOrNull()
                if (x == null || x < minOf(lo, hi) || x > maxOf(lo, hi)) {
                    Toast.makeText(ctx, R.string.dlg_invalid, Toast.LENGTH_SHORT).show()
                } else {
                    set(fromEdit(x))
                    sync()
                }
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun trim(d: Double): String = "%.2f".format(d).trimEnd('0').trimEnd('.').replace(',', '.')
}

object W {
    fun card(ctx: Context): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.setBackgroundResource(R.drawable.bg_card)
        c.clipToOutline = true
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, 0)
        c.layoutParams = lp
        return c
    }

    fun title(ctx: Context, s: String): TextView {
        val t = Ui.label(ctx, s.uppercase(), 12.5f, Ui.secondary(ctx), true)
        t.letterSpacing = 0.04f
        t.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 24), Ui.dp(ctx, 16), Ui.dp(ctx, 8))
        return t
    }

    fun divider(ctx: Context): View {
        val d = View(ctx)
        d.setBackgroundColor(Ui.outline(ctx))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        lp.marginStart = Ui.dp(ctx, 16)
        d.layoutParams = lp
        return d
    }

    fun pad(v: View, l: Int, t: Int, r: Int, b: Int): View {
        v.setPadding(Ui.dp(v.context, l), Ui.dp(v.context, t), Ui.dp(v.context, r), Ui.dp(v.context, b))
        return v
    }

    fun chip(ctx: Context, text: String, onClick: () -> Unit): TextView {
        val t = Ui.label(ctx, text, 14f, Ui.text(ctx))
        t.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 9), Ui.dp(ctx, 14), Ui.dp(ctx, 9))
        t.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 18)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = Ui.dp(ctx, 8)
        t.layoutParams = lp
        t.setOnClickListener { Ui.tap(it); onClick() }
        return t
    }

    /** Riga di opzioni dentro una scheda: titolo + segmenti */
    fun segRow(ctx: Context, title: String, seg: Segmented): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
        if (title.isNotEmpty()) {
            r.addView(Ui.label(ctx, title, 16f, Ui.text(ctx)).also { it.setPadding(0, 0, 0, Ui.dp(ctx, 8)) })
        }
        r.addView(seg, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return r
    }
}
